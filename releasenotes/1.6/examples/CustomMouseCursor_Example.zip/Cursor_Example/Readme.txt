Cursor textures from OpenGameArt: https://opengameart.org/content/knights-glove-mouse-cursor-0

Thanks!